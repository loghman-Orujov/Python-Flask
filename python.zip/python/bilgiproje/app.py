import os
from flask import Flask, render_template, request, redirect, url_for, flash, make_response, session ,g
from werkzeug.security import generate_password_hash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from datetime import datetime

# Flask uygulaması başlatma
app = Flask(__name__)
app.secret_key = os.urandom(24)  # Flash mesajlar için gerekli

# Veritabanı bağlantı ayarları
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:42831460Lg.@localhost:5432/BilgiProje'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# SQLAlchemy veritabanı bağlantısı
db = SQLAlchemy(app)

# Müşteri ve Ürün sınıfları (Model)
class Musteri(db.Model):
    __tablename__ = 'musteri'
    id = db.Column(db.Integer, primary_key=True)
    isim = db.Column(db.String(50), nullable=False)
    soyisim = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    telefon_no = db.Column(db.String(15), nullable=False)
    sifre = db.Column(db.String(255), nullable=False)
    urunler = db.relationship('MusteriUrun', back_populates='musteri')  # İlişki güncellendi

class Urun(db.Model):
    __tablename__ = 'urun'
    seri_no = db.Column(db.Integer, primary_key=True)
    tip = db.Column(db.String(50), nullable=False)
    klasman = db.Column(db.String(50), nullable=False)
    numara = db.Column(db.Integer, nullable=False)
    fiyat = db.Column(db.Numeric(10, 2), nullable=False)
    stok_miktari = db.Column(db.Integer, nullable=False)
    isim = db.Column(db.String(255), nullable=False)  # Yeni eklenen ürün ismi
    indirim = db.Column(db.Integer, nullable=False, default=0)  # Yeni eklenen indirim
    musteri_urun = db.relationship('MusteriUrun', back_populates='urun')  # İlişki güncellendi

class MusteriUrun(db.Model):
    __tablename__ = 'musteri_urun'
    musteri_id = db.Column(db.Integer, db.ForeignKey('musteri.id'), primary_key=True)
    urun_seri_no = db.Column(db.Integer, db.ForeignKey('urun.seri_no'), primary_key=True)
    urun_tipi = db.Column(db.String(50), nullable=False)  # Yeni eklenen ürün tipi
    urun_numara = db.Column(db.Integer, nullable=False)  # Yeni eklenen ürün numarası
    tarih = db.Column(db.DateTime, nullable=False)  # Satın alma tarihi
    urun = db.relationship('Urun', back_populates='musteri_urun')  # İlişki güncellendi
    musteri = db.relationship('Musteri', back_populates='urunler')  # İlişki güncellendi

class MusteriSorun(db.Model):
    __tablename__ = 'musteri_sorunlari'
    id = db.Column(db.Integer, primary_key=True)
    e_posta = db.Column(db.String(100), nullable=False)
    sorun_aciklama = db.Column(db.Text, nullable=False)
    sorun_tarihi = db.Column(db.DateTime, default=datetime.utcnow)
    durum = db.Column(db.String(50), default='Açık')  # Sorunun durumu
    cozulme_tarihi = db.Column(db.DateTime)
    cozum_aciklama = db.Column(db.Text)

    def __init__(self, e_posta, sorun_aciklama):
        self.e_posta = e_posta
        self.sorun_aciklama = sorun_aciklama
# Sepet verisi
cart = []
app.debug = False

@app.route('/')
def giris():
    return render_template('giris.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    sifre = request.form['sifre']
    
    # Kullanıcıyı veritabanında arama
    musteri = Musteri.query.filter_by(email=email, sifre=sifre).first()
    
    if musteri:
        # Müşteri ID'yi session'a kaydediyoruz
        session['musteri_id'] = musteri.id
        flash('Giriş başarılı!', 'success')
        return redirect(url_for('special_offers'))
    else:
        flash('E-posta veya şifre yanlış!', 'danger')
        return redirect(url_for('giris'))
    
@app.route('/kayit', methods=['GET', 'POST'])
def kayit():
    if request.method == 'POST':
        # Form verilerini al
        isim = request.form['name']
        soyisim = request.form['soyad']
        email = request.form['email']
        telefon_no = request.form['telefon_no']
        sifre = request.form['password']
        sifre_tekrar = request.form['confirm_password']
        
        # Şifre kontrolü
        if sifre != sifre_tekrar:
            flash('Şifreler eşleşmiyor!', 'danger')
            return redirect(url_for('kayit'))
        
        # Şifreyi güvenli hale getir
        hashed_sifre = generate_password_hash(sifre)
        
        # Müşteri oluştur
        yeni_musteri = Musteri(isim=isim, soyisim=soyisim, email=email, telefon_no=telefon_no, sifre=hashed_sifre)
        
        try:
            # Veritabanına kaydet
            db.session.add(yeni_musteri)
            db.session.commit()
            flash('Kayıt başarılı! Lütfen giriş yapın.', 'success')
            return redirect(url_for('giris'))
        except Exception as e:
            db.session.rollback()
            flash(f'Bir hata oluştu: {str(e)}', 'danger')
            return redirect(url_for('kayit'))

    return render_template('kayit.html')

@app.route('/pazar', methods=['GET', 'POST'])
def pazar():
    tip = request.args.get('tip')  # Filtreleme için tip parametresi
    indirimli = request.args.get('indirimli')  # İndirimli ürünleri filtrelemek için parametre

    if tip:
        if indirimli:  # Eğer 'indirimli' parametresi varsa
            urunler = Urun.query.filter_by(tip=tip).filter(Urun.indirim > 0).all()  # İndirimli ürünleri getir
        else:
            urunler = Urun.query.filter_by(tip=tip).all()  # Sadece belirtilen tipteki ürünleri getir
    else:
        if indirimli:  # Eğer 'indirimli' parametresi varsa
            urunler = Urun.query.filter(Urun.indirim > 0).all()  # Sadece indirimli ürünleri getir
        else:
            urunler = Urun.query.all()  # Tüm ürünleri getir

    total_price = sum(item.fiyat for item in cart)
    return render_template('pazar.html', urunler=urunler, total_price=total_price)

@app.route('/cart', methods=['GET'])
def cart_page():
    total_price = sum(item.fiyat for item in cart)
    return render_template('cart.html', cart=cart, total_price=total_price)

@app.route('/add_to_cart/<int:seri_no>', methods=['POST'])
def add_to_cart(seri_no):
    urun = Urun.query.get(seri_no)
    if urun:
        cart.append(urun)
        flash(f"{urun.numara} sepete eklendi!")
    return redirect(url_for('pazar'))

@app.route('/remove_from_cart/<int:seri_no>', methods=['POST'])
def remove_from_cart(seri_no):
    urun = Urun.query.get(seri_no)
    if urun in cart:
        cart.remove(urun)
        flash(f"{urun.numara} sepetten çıkarıldı!")
    return redirect(url_for('cart_page'))

@app.route('/checkout', methods=['POST'])
def checkout():
    email = request.form['email']
    
    # E-posta ile müşteri bilgilerini alıyoruz
    musteri = Musteri.query.filter_by(email=email).first()
    
    if not musteri:
        flash('E-posta ile ilgili müşteri bulunamadı.', 'danger')
        return redirect(url_for('giris'))  # Eğer müşteri bulunmazsa, giriş sayfasına yönlendir
    
    musteri_id = musteri.id  # Müşteri ID'sini alıyoruz

    # Müşteriye ait sepetteki tüm ürünleri alıyoruz
    cart = Urun.query.join(MusteriUrun, Urun.seri_no == MusteriUrun.urun_seri_no) \
        .filter(MusteriUrun.musteri_id == musteri_id).all()

    if not cart:
        flash('Sepetinizde ürün bulunmamaktadır.', 'danger')
        return redirect(url_for('pazar'))
    
    # Satın alma işlemi
    for urun in cart:
        if urun.stok_miktari <= 0:
            flash(f"{urun.isim} ürünü tükenmiş.", 'danger')
            return redirect(url_for('pazar'))
        
        # Ürünün stok miktarını azalt
        urun.stok_miktari -= 1
        
        # Satın alma işlemi veritabanına kaydediliyor
        yeni_musteri_urun = MusteriUrun(
            musteri_id=musteri_id,
            urun_seri_no=urun.seri_no,
            urun_tipi=urun.tip,
            urun_numara=urun.numara,
            satin_alma_tarihi=datetime.now()  # Satın alma tarihi
        )
        
        db.session.add(yeni_musteri_urun)

    # Veritabanı işlemlerini kaydediyoruz
    db.session.commit()

    # Sepeti boşaltıyoruz (MusteriUrun tablosundan silme işlemi)
    MusteriUrun.query.filter_by(musteri_id=musteri_id).delete()
    db.session.commit()

    flash('Satın alma işlemi başarıyla tamamlandı!', 'success')
    return redirect(url_for('pazar'))


@app.route('/special_offers', methods=['GET', 'POST'])
def special_offers():
    if request.method == 'POST':
        # Müşteri e-posta bilgisini alıyoruz
        email = request.form['email']
        
        # E-posta veritabanında doğrulama işlemi yapıyoruz
        musteri = Musteri.query.filter_by(email=email).first()
        
        if not musteri:
            flash('Bu e-posta adresiyle kayıtlı bir kullanıcı bulunamadı!', 'danger')
            return redirect(url_for('special_offers'))  # Kullanıcı e-posta adresiyle bulunamazsa tekrar yönlendir
        
        # Satın alınan ürünlerin tiplerini alıyoruz
        musteri_urunler = db.session.query(Urun.tip).join(MusteriUrun).filter(MusteriUrun.musteri_id == musteri.id).distinct().all()
        
        if not musteri_urunler:
            urunler = []  # Hiçbir ürün yoksa boş liste döndür
        else:
            urun_tipleri = [urun[0] for urun in musteri_urunler]  # Satın alınan ürünlerin tipleri
            urunler = Urun.query.filter(Urun.tip.in_(urun_tipleri)).all()  # Yalnızca o tipteki ürünleri alıyoruz
        
        return render_template('special_offers.html', urunler=urunler)
    
    # GET isteği geldiğinde sadece ürünleri gösteriyoruz
    # Burada giriş yapan müşteriye ait ürünlerin tiplerini listeleyelim
    # Örnek olarak, giriş yapan müşterinin ID'sini alıyoruz:
    musteri = current_user  # Burada kullanıcı doğrulaması yapılmalı
    
    musteri_urunler = db.session.query(Urun.tip).join(MusteriUrun).filter(MusteriUrun.musteri_id == musteri.id).distinct().all()
    
    if not musteri_urunler:
        urunler = []  # Hiçbir ürün yoksa boş liste döndür
    else:
        urun_tipleri = [urun[0] for urun in musteri_urunler]  # Satın alınan ürünlerin tipleri
        urunler = Urun.query.filter(Urun.tip.in_(urun_tipleri)).all()  # Yalnızca o tipteki ürünleri alıyoruz
    
    return render_template('special_offers.html', urunler=urunler)

@app.route('/sorun_ekle', methods=['GET', 'POST'])
def sorun_ekle():
    if request.method == 'POST':
        e_posta = request.form['email']
        sorun_aciklama = request.form['sorun_aciklama']
        
        # Sorunun veritabanına eklenmesi
        yeni_sorun = MusteriSorun(e_posta=e_posta, sorun_aciklama=sorun_aciklama)
        
        try:
            # Veritabanına kaydediyoruz
            db.session.add(yeni_sorun)
            db.session.commit()
            flash('Sorununuz başarıyla kaydedildi.', 'success')
            return redirect(url_for('pazar'))  # Pazar sayfasına yönlendir
        except Exception as e:
            db.session.rollback()
            flash(f'Bir hata oluştu: {str(e)}', 'danger')
            return redirect(url_for('sorun_ekle'))  # Hata durumunda tekrar formu göster
    
    return render_template('sorun_ekle.html')


@app.route('/logout')
def logout():
    response = make_response(redirect(url_for('giris')))
    response.delete_cookie('musteri_id')  # Çerezden müşteri ID'sini kaldır
    flash('Çıkış yapıldı!', 'success')
    return response

if __name__ == '__main__':
    app.run(debug=True)